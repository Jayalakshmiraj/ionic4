import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
students = [
{rollno:1,firstName:"jaya",lastName:"lakshmi",DOB:"03/14/19",subject:"english",teacher:"tamil",address:"hsr"},
{rollno:2,firstName:"mala",lastName:"devi",DOB:"04/15/19",subject:"tamil",teacher:"maths",address:"main road"},
{rollno:3,firstName:"kala",lastName:"devi",DOB:"05/16/19",subject:"english",teacher:"maths",address:"hsr"},
{rollno:4,firstName:"ragu",lastName:"kumar",DOB:"06/17/19",subject:"tamil",teacher:"math",address:"hsr"}]

student={rollno:0,firstName:"",lastName:"",DOB:"",subject:"value",teacher:"",address:""}

  constructor() { }

  getStudents(){
    return this.students;
  }

  getStudentByRollNo(rollno){
    for(var i=0;i<this.students.length;i++){
      if(this.students[i].rollno==rollno){
        return this.students[i];
        break;
      }
    }

  }
  addStudent(student){
  student.rollno = Math.round(Math.random()*1000000)
   this.students.push(student)

  }
  deleteStudent(rollno){

    for(var i=0;i<this.students.length;i++){
      if(rollno==this.students[i].rollno){
        this.students.splice(i,1)
        break;
      }

    }

  }

  updateStudent(student){
    for(var i=0;i<this.students.length;i++){
      if(this.students[i].rollno==student.rollno){
       this.students[i]=student;
        break;
      }
    }
  }
}
