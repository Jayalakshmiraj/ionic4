import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list.customer',
  templateUrl: './list.customer.component.html',
  styleUrls: ['./list.customer.component.scss'],
})
export class ListCustomerComponent implements OnInit {
  list:any = [];
  customer = { id: 0, name: "", email: "", phone: "" }
  constructor(private customerService: CustomerService,private router:Router) { }

  ngOnInit() {
    this.list = this.customerService.getCustomer()
  }


  deleteButton(id) {

   this.customerService.deleteCustomer(id);
  }
  deleteButtonAll() {
    this.list = []
  }

  editButton(customer){
  
this.router.navigate(['/edit-customer/'+customer]);
  }

}
